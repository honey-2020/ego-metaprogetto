 // preloader
 $(window).load(function(){
    $("#loader").delay(6000).fadeOut(500).stopp();

  })